using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class WoodPickup : MonoBehaviour
{
    public Vector3 spawnPoint;
    public FireScript.fuels type;
}
